import subprocess
def query_ollama(prompt):
   result = subprocess.run(
       ["ollama", "run", "phi"],
       input=prompt.encode(),
       stdout=subprocess.PIPE,
       stderr=subprocess.PIPE,
       timeout=300
   )
   return result.stdout.decode()