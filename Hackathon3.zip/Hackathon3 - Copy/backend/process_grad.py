from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import os
import pickle
model = SentenceTransformer("all-mpnet-base-v2")
# 🧠 Chunking with file info
def chunk_text_with_sources(file_text_map):
   # file_text_map = { "doc1.pdf": "long text...", "doc2.pdf": "..." }
   chunks = []
   for filename, text in file_text_map.items():
       # Example splitting logic
       parts = text.split("\n\n")  # or use text_splitter
       for part in parts:
           if part.strip():
               chunks.append({"text": part.strip(), "source": filename})
   return chunks
# 🔍 Embed only the chunk texts
def embed_chunks(chunks_with_source):
   texts = [chunk["text"] for chunk in chunks_with_source]
   return model.encode(texts)
# 🧠 Build & save FAISS index + source data
def create_faiss_index(chunks):
   # build and save index using chunk texts
   
   model = SentenceTransformer("all-MiniLM-L6-v2")
   embeddings = model.encode([chunk["text"] for chunk in chunks])
   index = faiss.IndexFlatL2(embeddings.shape[1])
   index.add(np.array(embeddings))

   # save chunks with source info
   with open("faiss_index.pkl", "wb") as f:
      pickle.dump((index, chunks), f)