import faiss
import numpy as np
import pickle
from sentence_transformers import SentenceTransformer
model = SentenceTransformer("all-mpnet-base-v2")
def search_similar_chunks(query, index_path="vector_store/index.faiss", k=5):
   index = faiss.read_index(index_path)
   with open(index_path.replace(".faiss", ".pkl"), "rb") as f:
       chunks = pickle.load(f)
   query_vec = model.encode([query])
   D, I = index.search(np.array(query_vec), k)
   return [chunks[i] for i in I[0]]