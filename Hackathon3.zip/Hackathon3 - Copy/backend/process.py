from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import os
import pickle
model = SentenceTransformer("all-mpnet-base-v2")
# 🧠 Chunking with file info
def chunk_text_with_sources(file_text_map, chunk_size=300, overlap=50):
   splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=overlap)
   all_chunks = []
   for filename, text in file_text_map.items():
       chunks = splitter.split_text(text)
       for chunk in chunks:
           all_chunks.append({
               "text": chunk,
               "source": filename
           })
   return all_chunks
# 🔍 Embed only the chunk texts
def embed_chunks(chunks_with_source):
   texts = [chunk["text"] for chunk in chunks_with_source]
   return model.encode(texts)
# 🧠 Build & save FAISS index + source data
def create_faiss_index(chunks_with_source, save_path="vector_store/index.faiss"):
   embeddings = embed_chunks(chunks_with_source)
   dim = embeddings.shape[1]
   index = faiss.IndexFlatL2(dim)
   index.add(np.array(embeddings))
   os.makedirs(os.path.dirname(save_path), exist_ok=True)
   faiss.write_index(index, save_path)
   # save chunks with source info
   with open(save_path.replace(".faiss", ".pkl"), "wb") as f:
       pickle.dump(chunks_with_source, f)